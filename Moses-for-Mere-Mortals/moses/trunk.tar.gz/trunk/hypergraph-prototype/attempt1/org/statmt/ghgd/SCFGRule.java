package org.statmt.ghgd;

import java.util.ArrayList;
import java.util.Properties;

public class SCFGRule extends Rule {

	@Override
	public String recoverString(ArrayList<Or> children, Properties p) {
		// TODO Auto-generated method stub
		return null;
	}

}

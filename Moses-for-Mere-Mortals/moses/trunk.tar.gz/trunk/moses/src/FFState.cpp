#include "FFState.h"

namespace Moses {

FFState::~FFState() {}

}


#ifndef _HASH_H_
#define _HASH_H_

// taken from burtleburtle.net/bob/hash/doobs.html
unsigned int quick_hash(register const char *k, register unsigned int length, register unsigned int initval);

#endif

